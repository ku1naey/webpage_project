import React from "react";

const TravelCard = ({ country, image, tags, onClick }) => {
  return (
    <div className="travel-card" onClick={onClick}>
      <img src={image} alt={country} className="travel-image" />
      <div className="travel-card-content">
        <h3 className="travel-country">{country}</h3>
        <div className="travel-tags">
          {tags?.map((tag, index) => (
            <span key={index} className="travel-tag">{tag}</span>
          ))}
        </div>
      </div>
    </div>
  );
};
export default TravelCard;
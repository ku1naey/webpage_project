// src/components/PageCard.jsx
import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom"; // 새 페이지 이동을 위해

const PageCard = ({ page, onPrev, onNext, isLast }) => {
  const navigate = useNavigate();

  const handleStart = () => {
    navigate("/start"); // 시작하기 눌렀을 때 이동할 경로
  };

  return (
    <motion.div
      key={page.id}
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -40 }}
      transition={{ duration: 0.5 }}
      className="card"
    >
      <h1>{page.title}</h1>
      <p>{page.subtitle}</p>

      {page.image && (
        <img
          src={require(`../assets/${page.image}`)}
          alt={page.title}
          className="page-image"
        />
      )}

      <div className="nav-buttons">
        <button onClick={onPrev}>← 이전</button>

        {isLast ? (
          <button onClick={handleStart}>시작하기 →</button>
        ) : (
          <button onClick={onNext}>다음 →</button>
        )}
      </div>
    </motion.div>
  );
};

export default PageCard;

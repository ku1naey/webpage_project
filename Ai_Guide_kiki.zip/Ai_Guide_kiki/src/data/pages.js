// 비디오 파일 import
import kikiBgVideo from "../assets/kiki-bg-video.mp4";

const pages = [
  {
    id: 1,
    title: "당신만의 AI 여행 가이드, KIKI",
    subtitle: "여행의 시작부터 끝까지, 단 하나의 AI 가이드로",
    backgroundVideo: kikiBgVideo, // import한 경로 사용
  },
  {
    id: 2,
    title: "🧠 AI 맞춤 일정 설계",
    subtitle: "여행 목적, 스타일, 예산에 맞는 맞춤 일정을 자동 추천",
    image: "plan.png",
  },
  {
    id: 3,
    title: "🗺️ 교통 & 동선 최적화",
    subtitle: "관광지 간 이동 시간, 교통수단까지 자동으로 계획",
    image: "map.png",
  },
  {
    id: 4,
    title: "📱 실시간 챗봇 안내",
    subtitle: "여행 중 생기는 질문도 실시간으로 답변받기",
    image: "chat.png",
  },
  {
    id: 5,
    title: "AI KIKI, 지금 만나보세요!",
    subtitle: "여행의 미래, 당신 곁에 KIKI",
    image: "kiki-logo.png",
  },
];

export default pages;

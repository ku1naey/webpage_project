import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./ResultPage.css";
import TravelCard from "../components/TravelCard";

import japan from "../assets/japan.jpg";
import france from "../assets/france.jpg";
import italy from "../assets/italy.jpg";
import usa from "../assets/usa.jpg";
import spain from "../assets/spain.jpg";
import uk from "../assets/uk.jpg";
import australia from "../assets/australia.jpg";
import canada from "../assets/canada.jpg";
import thailand from "../assets/thailand.jpg";
import switzerland from "../assets/switzerland.jpg";
import vietnam from "../assets/vietnam.jpg";
import turkey from "../assets/turkey.jpg";
import backgroundImg from "../assets/background.jpg";

const travelData = [
  {
    country: "일본",
    image: japan,
    tags: ["#주코쿠여행", "#요나고자유여행", "#마츠에자유여행", "#에어텔", "#오사카", "#교토"]
  },
  {
    country: "프랑스",
    image: france,
    tags: ["#파리여행", "#루브르박물관", "#에펠탑", "#낭만여행", "#유럽감성", "#에어텔"]
  },
  {
    country: "이탈리아",
    image: italy,
    tags: ["#로마", "#베네치아", "#피렌체", "#건축여행", "#역사탐방", "#미식투어"]
  },
  {
    country: "미국",
    image: usa,
    tags: ["#LA", "#뉴욕", "#그랜드캐니언", "#로드트립", "#자유여행", "#도시투어"]
  },
  {
    country: "스페인",
    image: spain,
    tags: ["#바르셀로나", "#가우디건축", "#플라멩코", "#마드리드", "#유럽감성", "#따뜻한여행"]
  },
  {
    country: "영국",
    image: uk,
    tags: ["#런던", "#빅벤", "#버킹엄궁전", "#해리포터투어", "#브리티시박물관", "#기차여행"]
  },
  {
    country: "호주",
    image: australia,
    tags: ["#시드니", "#오페라하우스", "#자연탐험", "#해변여행", "#에어텔", "#동물체험"]
  },
  {
    country: "캐나다",
    image: canada,
    tags: ["#자연여행", "#벤쿠버", "#나이아가라폭포", "#오로라", "#캠핑", "#겨울여행"]
  },
  {
    country: "태국",
    image: thailand,
    tags: ["#방콕", "#푸켓", "#마사지", "#저렴한여행", "#야시장", "#리조트"]
  },
  {
    country: "스위스",
    image: switzerland,
    tags: ["#인터라켄", "#융프라우", "#자연절경", "#기차여행", "#눈꽃여행", "#힐링"]
  },
  {
    country: "베트남",
    image: vietnam,
    tags: ["#하노이", "#다낭", "#호이안", "#저렴한여행", "#현지문화", "#맛집탐방"]
  },
  {
    country: "터키",
    image: turkey,
    tags: ["#이스탄불", "#카파도키아", "#열기구", "#지중해", "#문화여행", "#에어텔"]
  }
];

const ResultPage = () => {
  const cardWidth = 320; // 카드 + 여백 포함 가로 길이
  const visibleCards = 3;

  const [offset, setOffset] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();
  const { tour, healing, entertainment } = location.state || {};

  const maxOffset = (travelData.length - visibleCards) * cardWidth;

  const handlePrev = () => {
    setOffset((prev) => Math.max(prev - cardWidth, 0));
  };

  const handleNext = () => {
    setOffset((prev) => Math.min(prev + cardWidth, maxOffset));
  };

  const handleCardClick = (country) => {
    navigate("/recommend", {
      state: { tour, healing, entertainment, country },
    });
  };

  const slideStyle = {
    transform: `translateX(-${offset}px)`,
  };

  return (
    <div
      className="result-page"
      style={{
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
        <div
    style={{
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: "rgba(0, 0, 0, 0.5)", // 어둡게 정도 조절
      zIndex: 0,
    }}
       />
    <div style={{ position: "relative", zIndex: 1 }}>
      <h1>여행지를 선택하세요</h1>
      <div className="slider-container">
        <button className="slide-button left" onClick={handlePrev}>
          ◀
        </button>
        <div className="slider-wrapper">
          <div className="slider-track" style={slideStyle}>
            {travelData.map((item, idx) => (
              <TravelCard
                key={idx}
                country={item.country}
                image={item.image}
                tags={item.tags}
                onClick={() => handleCardClick(item.country)}
              />
            ))}
          </div>
        </div>
        <button className="slide-button right" onClick={handleNext}>
          ▶
        </button>
      </div>
       <button
        onClick={() => navigate("/start")}
        style={{
          marginTop: "3rem",
          padding: "0.8rem 2rem",
          fontSize: "1.1rem",
          backgroundColor: "#ffffff22",
          color: "white",
          border: "1px solid #ffffff44",
          borderRadius: "8px",
          cursor: "pointer",
      }}
    >
      이전 페이지로 돌아가기
    </button>
    </div>
    </div>
    
  );
};

export default ResultPage;

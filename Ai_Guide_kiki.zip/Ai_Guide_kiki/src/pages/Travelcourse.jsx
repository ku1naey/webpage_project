import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./TravelCourse.css";
import logoImage from "../assets/logo.png";

const TravelCourse = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { country } = location.state || {};

  const courses = [
    {
      title: `${country}의 대표 관광지`,
      description: `${country}에서 꼭 가봐야 할 명소를 소개할게요.`,
      image: require(`../assets/course/${country?.toLowerCase()}_course1.jpg`)
    },
    {
      title: `${country}의 힐링 스팟`,
      description: `자연과 쉼이 있는 힐링 여행지를 추천해요.`,
      image: require(`../assets/course/${country?.toLowerCase()}_course2.jpg`)
    },
    {
      title: `${country}의 오락 명소`,
      description: `신나게 놀고 즐길 수 있는 오락 여행지를\n알려드릴게요!`,
      image: require(`../assets/course/${country?.toLowerCase()}_course3.jpg`)
    },
  ];

  return (
    <div className="travel-course-page">
    <div className="travelcourse-header-bar">
      <div className="left-space">
        <button className="back-button" onClick={() => navigate(-1)}>← 뒤로가기</button>
      </div>
      <div className="right-space">
        <img src={logoImage} alt="로고" className="header-logo" />
        <span className="header-title">AI Guide Kiki</span>
      </div>
    </div>
      
      <h1>{country} 여행 추천 코스</h1>

      <div className="course-list">
        {courses.map((course, index) => (
          <div key={index} className="course-card">
            <img src={course.image} alt={course.title} className="course-image" />
            <div>
              <h3>{course.title}</h3>
              <p>
               {course.description.split("\n").map((line, i) => (
                <React.Fragment key={i}>
                  {line}
                  <br />
                </React.Fragment>
              ))}
              </p>
            </div>
          </div>
        ))}
      </div>
        <div className="footer-info-bar">
       지금까지의 코스추천 및 앞으로 추가될 교통편, 호텔예약 등은
      추후 실제 GPT API 등을 연동하여 실현할 계획입니다.
        </div>
    </div>
  );
};

export default TravelCourse;

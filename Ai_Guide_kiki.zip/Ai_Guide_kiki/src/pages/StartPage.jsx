import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./StartPage.css";

const Dial = ({ label, value, onChange }) => (
  <div className="dial">
    <h3>{label}</h3>
    <input
      type="range"
      min="0"
      max="10"
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
    />
    <span>{value}</span>
  </div>
);

const StartPage = () => {
  const [tour, setTour] = useState(5);
  const [healing, setHealing] = useState(5);
  const [entertainment, setEntertainment] = useState(5);
  const navigate = useNavigate();

  const handleConfirm = () => {
    navigate("/result");
  };

  return (
    <div className="start-dial-container">
      <h1>당신의 여행 스타일을 선택하세요</h1>

      <div className="dial-row">
        <Dial label="관광" value={tour} onChange={setTour} />
        <Dial label="힐링" value={healing} onChange={setHealing} />
        <Dial label="오락" value={entertainment} onChange={setEntertainment} />
      </div>

      <button className="confirm-button" onClick={handleConfirm}>
        확인
      </button>
    </div>
  );
};

export default StartPage;

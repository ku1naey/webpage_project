import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Chatbot.css";
import chatBg from "../assets/chatbackground.png";
import chatFrame from "../assets/chatroom.png";

const chatbotData = {
  root: {
    message: "안녕하세요! AI Guide Kiki 입니다. 무엇을 도와드릴까요?",
    options: [
      { text: "홈페이지 사용법을 알려줘", next: "1" },
      { text: "홈페이지를 소개해줘", next: "2" },
      { text: "너는 누구야?", next: "3" },
    ],
  },
  "1": {
    message: "네! 알려드릴게요. 어떤 것이 궁금하신가요?",
    options: [
      { text: "여행코스 짜는 법을 알려줘", next: "1-1" },
      { text: "어떤 기능이 있는지 알려줘", next: "1-2" },
      { text: "이전 대화로 돌아가줘", next: "root" },
    ],
  },
  "1-1": {
    message: "나라를 선택하면 나오는 메인 페이지에서 사진을 클릭하세요!\n또 궁금한 게 있으신가요?",
    options: [
      { text: "처음 대화로 돌아가줘", next: "root" },
      { text: "이전 대화로 돌아가줘", next: "1" },
    ],
  },
  "1-2": {
    message:
      "현재 구현된 기능은 크게 세 가지에요!\n" +
      "첫째, 다이얼과 나라 선택으로 취향 반영 여행코스를 추천해 드립니다!\n" +
      "둘째, 선택한 코스에 따라 가이드와 예약도 도와드려요!\n" +
      "셋째, 지금 저 같은 챗봇이 구현되어 있어요!\n또 궁금한 게 있으신가요?",
    options: [
      { text: "처음 대화로 돌아가줘", next: "root" },
      { text: "이전 대화로 돌아가줘", next: "1" },
    ],
  },
  "2": {
    message: "네! 홈페이지를 소개해드릴게요. 어떤 것을 소개해드릴까요?",
    options: [
      { text: "홈페이지 첫 화면에 나온 개요를 보고 싶어", next: "2-1" },
      { text: "홈페이지는 어떻게 만들어졌어?", next: "2-2" },
      { text: "이전 대화로 돌아가줘", next: "root" },
    ],
  },
  "2-1": {
    message: "네! 알겠어요. 아래 버튼을 클릭하시면 홈페이지 첫 화면으로 이동해요!",
    options: [
      { text: "첫 페이지 보기", action: () => window.location.href = "/" },
      { text: "보지 않기", next: "root" },
    ],
  },
  "2-2": {
    message:
      "KIKI는 React + Webpack + Framer Motion + React Router 기반 SPA 프로젝트에요!\n" +
      "챗GPT와 겁없는 신입생의 무모한 도전이 만들어낸 작품이라고 볼 수 있죠!\n또 궁금한게 있으신가요?",
    options: [
      { text: "처음 대화로 돌아가줘", next: "root" },
      { text: "이전 대화로 돌아가줘", next: "2" },
    ],
  },
  "3": {
    message:
      "저는 사실 진짜 AI는 아니고 코드로 작성된 데이터더미에요.\n" +
      "아마 저를 만든 사람은 시간 빌 게이츠이거나 VScode와 연애하는 불쌍한 공돌이일지도 몰라요.",
    options: [{ text: "처음 대화로 돌아가줘", next: "root" }],
  },
};

const Chatbot = () => {
  const [history, setHistory] = useState([{ id: "root", from: "bot" }]);
  const scrollRef = useRef(null);
  const navigate = useNavigate();

  const current = chatbotData[history[history.length - 1].id];

  const handleOptionClick = (option) => {
    if (option.action) {
      option.action();
      return;
    }
    setHistory([...history, { id: option.next, from: "bot" }]);
  };

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history]);

  return (
    <div className="chatbot-outer">
      <img src={chatBg} className="background-image" />
      <div className="chatbot-phone-frame">
        <img src={chatFrame} className="chatroom-frame" />
        <button className="exit-button" onClick={() => navigate(-1)}>←</button>
        <div className="chat-window-inside">
          {history.map((entry, idx) => {
            const node = chatbotData[entry.id];
            return (
              <div key={idx} className="chat-bubble bot">
                {node.message.split("\n").map((line, i) => (
                  <p key={i}>{line}</p>
                ))}
              </div>
            );
          })}
          <div className="option-container">
            {current.options.map((opt, idx) => (
              <button key={idx} onClick={() => handleOptionClick(opt)}>
                {opt.text}
              </button>
            ))}
          </div>
          <div ref={scrollRef} />
        </div>
      </div>
    </div>
  );
};

export default Chatbot;
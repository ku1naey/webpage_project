import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./RecommendPage.css";
import logoImage from "../assets/logo.png";
import hotelsBanner from "../assets/hotelscombine.png";
import ssgCard from "../assets/ssg.png";
import kbCard from "../assets/kb.png";
import solCard from "../assets/sol.png";

const RecommendPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { country } = location.state || {};

  const slideImages = [
  require(`../assets/algorithm/${country?.toLowerCase()}1.jpg`),
  require(`../assets/algorithm/${country?.toLowerCase()}2.jpg`)
  ];

  const [currentSlide, setCurrentSlide] = useState(0);

  const handleSlideClick = () => {
  navigate("/Travelcourse", {
    state: {
      country,
    },
  });
};

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slideImages.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [slideImages.length]);

  const handleDotClick = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div className="recommend-page">
      <header className="recommend-navbar">
        <div className="nav-left">
          <img src={logoImage} alt="로고" className="logo-image" />
          <div className="nav-title">
            " <span className="highlight0">AI Guide Kiki</span> " 고객님, <span className="highlight">어떤 여행</span>을 <span className="highlight2">꿈꾸시나요?</span>
          </div>
        </div>
        <div className="nav-right">
          <span className="nav-item" onClick={() => navigate("/chatbot")}>챗봇</span>
          <span className="nav-item" onClick={() => navigate("/result")}>다른여행지</span>
        </div>
      </header>

      <main className="recommend-body">
        <section className="left-section">
          <h2>AI가 추천하는<br/>패키지를 직접 만나보세요!</h2>
        </section>
        <section className="right-section">
          <img
            src={slideImages[currentSlide]}
            alt="슬라이드 이미지"
            className="slide-image"
            onClick={handleSlideClick}
          />
          <div className="dot-container">
            {slideImages.map((_, idx) => (
              <span
                key={idx}
                className={`dot ${currentSlide === idx ? "active" : ""}`}
                onClick={() => handleDotClick(idx)}
              ></span>
            ))}
          </div>
        </section>
      </main>

      <section className="image-section">
        <img src={hotelsBanner} alt="배너" className="full-width-image" />
      </section>

      <section className="card-benefits">
        <div className="card-item">
          <img src={ssgCard} alt="삼성카드" className="card-img" />
          <span className="card-label">정상가 대비 최대 15% 할인!</span>
        </div>
        <div className="card-item">
          <img src={kbCard} alt="국민카드" className="card-img" />
          <span className="card-label">호텔 최대 30% 즉시할인!</span>
        </div>
        <div className="card-item">
          <img src={solCard} alt="신한카드" className="card-img" />
          <span className="card-label">환전 결제 인출 등 수수료 면제! </span>
        </div>
      </section>
    </div>
  );
};

export default RecommendPage;

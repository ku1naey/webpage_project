import React, { useState } from "react";
import { AnimatePresence } from "framer-motion";
import pages from "../data/pages";
import PageCard from "../components/PageCard";
import "./AIKikiPresentation.css";

const AIKikiPresentation = () => {
  const [pageIndex, setPageIndex] = useState(0);
  const page = pages[pageIndex];
  const isLast = pageIndex === pages.length - 1;

  const nextPage = () => setPageIndex((prev) => (prev + 1) % pages.length);
  const prevPage = () => setPageIndex((prev) => (prev - 1 + pages.length) % pages.length);

  return (
    <div className="presentation-container">
      {
        <video
          autoPlay
          muted
          loop
          className="background-video"
          src={pages[0].backgroundVideo} // 항상 첫 페이지 비디오로 고정
        />
      }

      <AnimatePresence mode="wait">
        <PageCard
          page={page}
          onPrev={prevPage}
          onNext={nextPage}
          isLast={isLast}
        />
      </AnimatePresence>
    </div>
  );
};

export default AIKikiPresentation;

import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AIKikiPresentation from "./pages/AIKikiPresentation";
import StartPage from "./pages/StartPage";
import ResultPage from "./pages/ResultPage";
import RecommendPage from "./pages/RecommendPage";
import Chatbot from "./pages/Chatbot";
import TravelCourse from "./pages/Travelcourse";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AIKikiPresentation />} />
        <Route path="/start" element={<StartPage />} />
        <Route path="/result" element={<ResultPage />} />
        <Route path="/recommend" element={<RecommendPage />} />
        <Route path="/Travelcourse" element={<TravelCourse />} />
        <Route path="/chatbot" element={<Chatbot />} />
      </Routes>
    </Router>
  );
};

export default App;

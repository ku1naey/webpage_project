const path = require("path");

module.exports = {
  entry: "./src/index.js", // 시작점
  output: {
    path: path.resolve(__dirname, "dist"), // 빌드 결과 폴더
    filename: "bundle.js", // 빌드된 파일 이름
    publicPath: "/", // 개발 서버 기준 경로
  },
  module: {
    rules: [
      {
        test: /\.jsx?$/, // .js나 .jsx 파일
        exclude: /node_modules/,
        use: "babel-loader",
      },
      {
        test: /\.css$/, // CSS 파일
        use: ["style-loader", "css-loader"],
      },
      {
        test: /\.(png|jpe?g|gif|mp4)$/i,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[hash].[ext]',
              outputPath: 'assets',
              esModule: false,
            },
          },
        ],
      },
    ],
  },
  resolve: {
    extensions: [".js", ".jsx"], // 확장자 생략 가능
  },
  devServer: {
    static: path.join(__dirname, "public"), // index.html 위치
    port: 3000, // 로컬 서버 포트
    historyApiFallback: true, // SPA 지원
    hot: true, // HMR (핫 모듈 리로딩)
  },
  mode: "development",
};
